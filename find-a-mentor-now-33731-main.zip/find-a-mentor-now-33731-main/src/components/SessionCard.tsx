import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, MapPin, User } from "lucide-react";
import { Link } from "react-router-dom";

interface SessionCardProps {
  id: number;
  subject: string;
  tutor: string;
  date: string;
  time: string;
  location: string;
  level: string;
}

const SessionCard = ({ id, subject, tutor, date, time, location, level }: SessionCardProps) => {
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <h3 className="text-lg font-semibold text-foreground">{subject}</h3>
            <div className="flex items-center gap-2 mt-2 text-sm text-muted-foreground">
              <User className="h-4 w-4" />
              <span>{tutor}</span>
            </div>
          </div>
          <Badge variant="secondary">{level}</Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-2">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Calendar className="h-4 w-4" />
          <span>{date}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Clock className="h-4 w-4" />
          <span>{time}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <MapPin className="h-4 w-4" />
          <span>{location}</span>
        </div>
      </CardContent>
      <CardFooter>
        <Link to={`/session/${id}`} className="w-full">
          <Button className="w-full">Sign Up</Button>
        </Link>
      </CardFooter>
    </Card>
  );
};

export default SessionCard;
