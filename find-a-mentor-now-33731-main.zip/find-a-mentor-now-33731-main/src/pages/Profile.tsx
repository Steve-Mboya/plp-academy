import Navbar from "@/components/Navbar";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Mail, MapPin, Calendar, BookOpen } from "lucide-react";

const Profile = () => {
  const userSessions = [
    {
      id: 1,
      subject: "Mathematics - Algebra",
      date: "March 15, 2025",
      time: "2:00 PM - 3:00 PM",
      status: "upcoming"
    },
    {
      id: 2,
      subject: "English Literature",
      date: "March 16, 2025",
      time: "4:00 PM - 5:00 PM",
      status: "upcoming"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Profile Info */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <div className="flex flex-col items-center text-center">
                  <Avatar className="h-24 w-24 mb-4">
                    <AvatarFallback className="text-2xl bg-primary text-primary-foreground">
                      JD
                    </AvatarFallback>
                  </Avatar>
                  <h2 className="text-2xl font-semibold text-foreground mb-1">
                    John Doe
                  </h2>
                  <Badge variant="secondary">Student</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3 text-sm text-muted-foreground">
                  <Mail className="h-4 w-4" />
                  <span>john.doe@email.com</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-muted-foreground">
                  <MapPin className="h-4 w-4" />
                  <span>New York, NY</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-muted-foreground">
                  <Calendar className="h-4 w-4" />
                  <span>Member since Jan 2025</span>
                </div>
                <Button className="w-full mt-4" variant="outline">
                  Edit Profile
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Sessions */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <h3 className="text-xl font-semibold text-foreground">
                  My Sessions
                </h3>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {userSessions.map((session) => (
                    <div 
                      key={session.id}
                      className="flex items-start justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex items-start gap-3">
                        <div className="p-2 bg-primary/10 rounded-lg">
                          <BookOpen className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <h4 className="font-medium text-foreground">
                            {session.subject}
                          </h4>
                          <p className="text-sm text-muted-foreground mt-1">
                            {session.date} at {session.time}
                          </p>
                        </div>
                      </div>
                      <Badge>
                        {session.status}
                      </Badge>
                    </div>
                  ))}
                </div>
                {userSessions.length === 0 && (
                  <div className="text-center py-12 text-muted-foreground">
                    <BookOpen className="h-12 w-12 mx-auto mb-4 opacity-20" />
                    <p>No sessions booked yet</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
