import Navbar from "@/components/Navbar";
import SessionCard from "@/components/SessionCard";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";

const Index = () => {
  const sessions = [
    {
      id: 1,
      subject: "Mathematics - Algebra",
      tutor: "Sarah Johnson",
      date: "March 15, 2025",
      time: "2:00 PM - 3:00 PM",
      location: "Central Library, Room 204",
      level: "High School"
    },
    {
      id: 2,
      subject: "English Literature",
      tutor: "Michael Chen",
      date: "March 16, 2025",
      time: "4:00 PM - 5:00 PM",
      location: "Community Center",
      level: "College"
    },
    {
      id: 3,
      subject: "Chemistry",
      tutor: "Emily Rodriguez",
      date: "March 17, 2025",
      time: "3:00 PM - 4:30 PM",
      location: "Science Building, Lab 3",
      level: "High School"
    },
    {
      id: 4,
      subject: "Spanish Basics",
      tutor: "David Martinez",
      date: "March 18, 2025",
      time: "5:00 PM - 6:00 PM",
      location: "Online via Zoom",
      level: "Beginner"
    },
    {
      id: 5,
      subject: "Computer Science - Python",
      tutor: "Alex Thompson",
      date: "March 19, 2025",
      time: "6:00 PM - 7:30 PM",
      location: "Tech Hub, Room 101",
      level: "Intermediate"
    },
    {
      id: 6,
      subject: "Physics",
      tutor: "Dr. Lisa Wang",
      date: "March 20, 2025",
      time: "1:00 PM - 2:30 PM",
      location: "University Campus",
      level: "College"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="bg-muted border-b">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-2xl">
            <h1 className="text-4xl font-bold text-foreground mb-4">
              Find Free Tutoring Sessions in Your Area
            </h1>
            <p className="text-lg text-muted-foreground mb-8">
              Connect with volunteer tutors who are passionate about helping students succeed. 
              Browse available sessions and sign up today.
            </p>
            
            {/* Search Bar */}
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                  placeholder="Search by subject, tutor, or location..." 
                  className="pl-10"
                />
              </div>
              <Button>Search</Button>
            </div>
          </div>
        </div>
      </section>

      {/* Sessions Grid */}
      <section className="container mx-auto px-4 py-12">
        <div className="mb-8">
          <h2 className="text-2xl font-semibold text-foreground mb-2">
            Upcoming Sessions
          </h2>
          <p className="text-muted-foreground">
            {sessions.length} tutoring sessions available
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sessions.map((session) => (
            <SessionCard key={session.id} {...session} />
          ))}
        </div>
      </section>
    </div>
  );
};

export default Index;
